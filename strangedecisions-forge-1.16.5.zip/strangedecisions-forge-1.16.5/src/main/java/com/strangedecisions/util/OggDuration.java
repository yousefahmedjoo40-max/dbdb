package com.strangedecisions.util;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.IResource;
import net.minecraft.util.ResourceLocation;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Reads the REAL duration of an .ogg Vorbis file from its own headers (sample rate + last page granule position).
 * Used only as a fallback when the sound engine never reports the track as playing (e.g. music volume = 0),
 * so the story still progresses after exactly the length of the track instead of an arbitrary timeout.
 */
public final class OggDuration {
    private OggDuration() {}

    /** @return duration in game ticks, or -1 if it cannot be determined. */
    public static long ticks(Minecraft mc, ResourceLocation file) {
        try (IResource res = mc.getResourceManager().getResource(file); InputStream in = res.getInputStream()) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            double seconds = seconds(bos.toByteArray());
            return seconds > 0 ? (long) Math.ceil(seconds * 20.0) : -1;
        } catch (Exception ex) {
            return -1;
        }
    }

    public static double seconds(byte[] d) {
        // Vorbis identification header: 0x01 "vorbis" | version(4) | channels(1) | sampleRate(4, LE)
        byte[] sig = {1, 'v', 'o', 'r', 'b', 'i', 's'};
        int idx = -1;
        for (int i = 0; i + sig.length + 9 < d.length && i < 4096; i++) {
            boolean ok = true;
            for (int j = 0; j < sig.length; j++) {
                if (d[i + j] != sig[j]) { ok = false; break; }
            }
            if (ok) { idx = i; break; }
        }
        if (idx < 0) return -1;
        int o = idx + 12;
        long rate = (d[o] & 0xFFL) | ((d[o + 1] & 0xFFL) << 8) | ((d[o + 2] & 0xFFL) << 16) | ((d[o + 3] & 0xFFL) << 24);
        if (rate <= 0) return -1;
        for (int i = d.length - 27; i >= 0; i--) {
            if (d[i] == 'O' && d[i + 1] == 'g' && d[i + 2] == 'g' && d[i + 3] == 'S') {
                long g = 0;
                for (int k = 7; k >= 0; k--) g = (g << 8) | (d[i + 6 + k] & 0xFFL);
                if (g > 0) return (double) g / (double) rate;
            }
        }
        return -1;
    }
}
