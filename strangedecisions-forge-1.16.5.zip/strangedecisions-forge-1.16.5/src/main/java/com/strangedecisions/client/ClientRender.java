package com.strangedecisions.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import com.strangedecisions.JumpscareType;
import com.strangedecisions.StrangeDecisions;
import com.strangedecisions.config.HorrorConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.renderer.texture.NativeImage;
import net.minecraft.resources.IResource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.io.InputStream;
import java.util.EnumMap;
import java.util.Map;
import java.util.Random;

/** All client-side drawing: countdown HUD, jumpscare overlay (also over open screens), shake, input freeze. */
@Mod.EventBusSubscriber(modid = StrangeDecisions.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientRender {
    private static final Random RNG = new Random();
    private static final Map<JumpscareType, int[]> SIZES = new EnumMap<>(JumpscareType.class);

    private ClientRender() {}

    // ------------------------------------------------------------------ HUD + overlay over the game

    @SubscribeEvent
    public static void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getMainWindow().getScaledWidth();
        int h = mc.getMainWindow().getScaledHeight();
        if (ClientChase.hudVisible() && !ClientJumpscare.isActive()) drawHud(e.getMatrixStack(), mc, w, h);
        if (ClientJumpscare.isActive()) drawJumpscare(e.getMatrixStack(), mc, w, h, e.getPartialTicks());
    }

    /** Jumpscare must also appear above inventories, chat, etc. */
    @SubscribeEvent
    public static void onScreen(GuiScreenEvent.DrawScreenEvent.Post e) {
        if (!ClientJumpscare.isActive()) return;
        Minecraft mc = Minecraft.getInstance();
        drawJumpscare(e.getMatrixStack(), mc, mc.getMainWindow().getScaledWidth(),
                mc.getMainWindow().getScaledHeight(), e.getRenderPartialTicks());
    }

    private static void drawHud(MatrixStack ms, Minecraft mc, int w, int h) {
        float in = ClientChase.intensity();
        String text = "HE IS AWAY FROM YOU: " + ClientChase.shownDistance() + " BLOCKS";

        // red vignette that grows with the tension
        int a = (int) (in * 90) + (int) (Math.sin((ClientChase.ticks) * (0.2 + in)) * 12 * in);
        a = Math.max(0, Math.min(150, a));
        if (a > 0) {
            AbstractGui.fill(ms, 0, 0, w, h / 5, (a << 24) | 0x600000);
            AbstractGui.fill(ms, 0, h - h / 5, w, h, (a << 24) | 0x600000);
        }

        int fw = mc.fontRenderer.getStringWidth(text);
        float scale = Math.min(2.2F + in * 0.8F, (w * 0.92F) / Math.max(1, fw));
        float jx = (RNG.nextFloat() - 0.5F) * in * 5.0F;
        float jy = (RNG.nextFloat() - 0.5F) * in * 5.0F;
        int gb = (int) (255 * (1.0F - in * 0.85F));
        int color = 0xFF000000 | (255 << 16) | (gb << 8) | gb;

        RenderSystem.enableBlend();
        ms.push();
        ms.translate(w / 2.0F + jx, h * 0.12F + jy, 0.0F);
        ms.scale(scale, scale, 1.0F);
        mc.fontRenderer.drawStringWithShadow(ms, text, -fw / 2.0F, 0.0F, color);
        ms.pop();
    }

    // ------------------------------------------------------------------ jumpscare drawing

    private static void drawJumpscare(MatrixStack ms, Minecraft mc, int w, int h, float pt) {
        JumpscareType type = ClientJumpscare.type();
        if (type == null) return;
        float t = ClientJumpscare.elapsed(pt);
        float total = ClientJumpscare.total();
        float p = Math.max(0.0F, Math.min(1.0F, t / total));

        float alpha = 1.0F;
        float zoom = 1.06F;
        float shake = 0.0F;
        int tintColor = 0;
        float tintAlpha = 0.0F;

        switch (type) {
            case SECOND:      // hard cut, creeping zoom, violent shake, blood-red pulse, fade at the very end
                zoom = 1.08F + 0.25F * p * p;
                shake = 7.0F * (1.0F - p * 0.5F);
                tintColor = 0xB00000;
                tintAlpha = 0.18F + 0.12F * (float) Math.sin(t * 0.9F);
                if (total - t < 15) alpha = Math.max(0.0F, (total - t) / 15.0F);
                break;
            case PORTRAIT:    // quick punch-in
                zoom = 1.25F - 0.17F * Math.min(1.0F, t / 6.0F);
                shake = 10.0F * (1.0F - p);
                if (total - t < 8) alpha = Math.max(0.0F, (total - t) / 8.0F);
                break;
            case PEEK:        // quiet flicker: fades in, flickers, fades out
                alpha = (float) Math.min(1.0F, t / 6.0F) * Math.min(1.0F, (total - t) / 12.0F);
                if (((int) (t / 3)) % 5 == 4) alpha *= 0.5F;
                zoom = 1.02F;
                break;
            case PRISON:      // slow dread fade-in/out
                alpha = Math.min(1.0F, t / 25.0F) * Math.min(1.0F, (total - t) / 30.0F);
                zoom = 1.02F + 0.06F * p;
                break;
            default:
                break;
        }
        alpha = Math.max(0.0F, Math.min(1.0F, alpha));

        int[] size = sizeOf(mc, type);
        int iw = size[0], ih = size[1];
        float cover = Math.max((float) w / iw, (float) h / ih);   // "cover" fit: always fills the whole screen
        float uw = w / cover;
        float vh = h / cover;
        float u0 = (iw - uw) / 2.0F;
        float v0 = (ih - vh) / 2.0F;

        float jx = shake > 0 ? (RNG.nextFloat() - 0.5F) * shake : 0;
        float jy = shake > 0 ? (RNG.nextFloat() - 0.5F) * shake : 0;

        // black backing so a fade never shows the world behind a half-transparent picture
        if (alpha > 0.0F) AbstractGui.fill(ms, 0, 0, w, h, ((int) (alpha * 255) << 24));

        mc.getTextureManager().bindTexture(type.textureLocation());
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.color4f(1.0F, 1.0F, 1.0F, alpha);
        ms.push();
        ms.translate(w / 2.0F + jx, h / 2.0F + jy, 0.0F);
        ms.scale(zoom, zoom, 1.0F);
        ms.translate(-w / 2.0F, -h / 2.0F, 0.0F);
        AbstractGui.blit(ms, 0, 0, w, h, u0, v0, (int) uw, (int) vh, iw, ih);
        ms.pop();
        RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);

        if (tintAlpha > 0.0F) {
            int ta = (int) (Math.max(0.0F, Math.min(1.0F, tintAlpha * alpha)) * 255);
            AbstractGui.fill(ms, 0, 0, w, h, (ta << 24) | tintColor);
        }
        if (type == JumpscareType.SECOND && t < 3.0F) {            // white flash on the first frames
            int fa = (int) (200 * (1.0F - t / 3.0F));
            AbstractGui.fill(ms, 0, 0, w, h, (fa << 24) | 0xFFFFFF);
        }
    }

    /** Reads the real pixel size of the PNG once (images were supplied at different resolutions). */
    private static int[] sizeOf(Minecraft mc, JumpscareType type) {
        int[] s = SIZES.get(type);
        if (s != null) return s;
        s = new int[]{256, 256};
        try (IResource res = mc.getResourceManager().getResource(type.textureLocation());
             InputStream in = res.getInputStream();
             NativeImage img = NativeImage.read(in)) {
            s = new int[]{img.getWidth(), img.getHeight()};
        } catch (Exception ignored) {
            // keep the fallback; the texture itself will show as missing which makes the problem obvious
        }
        SIZES.put(type, s);
        return s;
    }

    // ------------------------------------------------------------------ camera shake, input freeze, vanilla music mute

    @SubscribeEvent
    public static void onCamera(EntityViewRenderEvent.CameraSetup e) {
        if (!HorrorConfig.CAMERA_SHAKE.get()) return;
        float amp = 0.0F;
        if (ClientChase.hudVisible()) {
            float in = ClientChase.intensity();
            amp = in * in * 0.9F;
        }
        JumpscareType t = ClientJumpscare.type();
        if (t == JumpscareType.SECOND || t == JumpscareType.PORTRAIT) amp = Math.max(amp, 2.2F);
        if (amp < 0.02F) return;
        float time = (float) (ClientChase.ticks + e.getRenderPartialTicks());
        e.setPitch(e.getPitch() + (float) Math.sin(time * 1.7F) * amp);
        e.setYaw(e.getYaw() + (float) Math.cos(time * 2.3F) * amp);
        e.setRoll(e.getRoll() + (float) Math.sin(time * 3.1F) * amp * 0.6F);
    }

    @SubscribeEvent
    public static void onInput(InputUpdateEvent e) {
        if (!ClientJumpscare.freezeInput()) return;
        e.getMovementInput().moveForward = 0.0F;
        e.getMovementInput().moveStrafe = 0.0F;
        e.getMovementInput().forwardKeyDown = false;
        e.getMovementInput().backKeyDown = false;
        e.getMovementInput().leftKeyDown = false;
        e.getMovementInput().rightKeyDown = false;
        e.getMovementInput().jump = false;
    }

    /** While the horror music plays, vanilla background music is muted so the two never overlap. */
    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent e) {
        if (!ClientChase.isActive() || e.getSound() == null) return;
        if (e.getSound().getCategory() == SoundCategory.MUSIC && !ClientChase.isOurMusic(e.getSound())) {
            e.setResultSound(null);
        }
    }
}
