package com.strangedecisions.client;

import com.strangedecisions.JumpscareType;
import com.strangedecisions.ModSounds;
import com.strangedecisions.StrangeDecisions;
import com.strangedecisions.network.ChasePacket;
import com.strangedecisions.network.ModNetwork;
import com.strangedecisions.network.MusicFinishedPacket;
import com.strangedecisions.util.OggDuration;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.SimpleSound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Client side of the chase: HUD state, chase music (start / loop / natural-end detection),
 * heartbeat, and the hand-off to the jumpscare overlay.
 *
 * MUSIC RULES
 *  - the track is started once (never per tick) and tracked via SoundHandler.isPlaying()
 *  - during the chase it is only restarted after it has FINISHED (loop option)
 *  - at the climax the running track is kept as is; the scream is a separate sound
 *  - the server is told "music finished" only when the track ended naturally
 */
@Mod.EventBusSubscriber(modid = StrangeDecisions.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientChase {
    private enum Phase { IDLE, CHASE, CLIMAX, WAIT_RESTORE }

    private static final ResourceLocation CHASE_FILE = new ResourceLocation(StrangeDecisions.MODID, "sounds/chase_music.ogg");
    private static final ResourceLocation ENDING_FILE = new ResourceLocation(StrangeDecisions.MODID, "sounds/ending_music.ogg");

    /** Client tick counter that does not advance while the game is paused. */
    public static long ticks;

    private static Phase phase = Phase.IDLE;
    private static int sessionId;
    private static int shown;
    private static int initial = 200;
    private static float intensity;
    private static boolean loop;
    private static boolean heartbeat;
    private static float volume = 1.0F;

    private static ISound music;
    private static long musicStart;
    private static long musicDurationTicks = -1;
    private static boolean seenPlaying;
    private static boolean awaitingEnd;
    private static long endSentAt;
    private static boolean reportedMissing;

    private static ISound ending;
    private static int heartbeatCooldown;
    private static int secondBeat = -1;

    private ClientChase() {}

    // ------------------------------------------------------------------ queries used by the renderer

    public static boolean hudVisible() { return phase == Phase.CHASE; }
    public static int shownDistance() { return shown; }
    public static float intensity() { return intensity; }
    public static boolean isActive() { return phase != Phase.IDLE; }

    public static boolean isOurMusic(ISound s) {
        return s != null && (s == music || s == ending);
    }

    // ------------------------------------------------------------------ packets

    public static void handle(ChasePacket p) {
        Minecraft mc = Minecraft.getInstance();
        switch (p.type) {
            case ChasePacket.START:
                reset(true);
                phase = Phase.CHASE;
                sessionId = p.session;
                shown = p.distance;
                initial = Math.max(1, p.distance);
                loop = p.loop;
                heartbeat = p.heartbeat;
                volume = p.volume;
                startMusic(mc);
                break;
            case ChasePacket.UPDATE:
                if (p.session == sessionId && phase == Phase.CHASE) {
                    shown = p.distance;
                    intensity = p.intensity;
                }
                break;
            case ChasePacket.JUMPSCARE:
                JumpscareType t = JumpscareType.byOrdinal(p.jumpscare);
                if (t != null) ClientJumpscare.show(t, p.ticks, p.sound, p.freeze);
                if (p.climax && p.session == sessionId && phase != Phase.IDLE) {
                    beginClimax(mc);
                }
                break;
            case ChasePacket.ENDING:
                playEnding(mc);
                break;
            case ChasePacket.RESTORE:
                reset(false);
                break;
            case ChasePacket.CANCEL:
                reset(true);
                break;
            default:
                break;
        }
    }

    private static void beginClimax(Minecraft mc) {
        phase = Phase.CLIMAX;
        awaitingEnd = true;
        intensity = 1.0F;
        // Keep the music that is already playing. Only start it if nothing is running right now.
        if (music == null && !startMusic(mc)) {
            sendFinished();
        }
    }

    // ------------------------------------------------------------------ music

    private static boolean startMusic(Minecraft mc) {
        if (!mc.getResourceManager().hasResource(CHASE_FILE)) {
            if (!reportedMissing && mc.player != null) {
                reportedMissing = true;
                mc.player.sendStatusMessage(new StringTextComponent(
                        "[Strange Decisions] chase_music.ogg is missing - it must be supplied in assets/strangedecisions/sounds/"), false);
            }
            music = null;
            return false;
        }
        musicDurationTicks = OggDuration.ticks(mc, CHASE_FILE);
        mc.getMusicTicker().stop();   // silence vanilla background music
        ISound s = new SimpleSound(ModSounds.CHASE_MUSIC.get(), SoundCategory.MUSIC, volume, 1.0F, false, 0,
                ISound.AttenuationType.NONE, 0.0D, 0.0D, 0.0D, true);
        music = s;                    // assign BEFORE play so the PlaySoundEvent filter recognises it
        musicStart = ticks;
        seenPlaying = false;
        mc.getSoundHandler().play(s);
        return true;
    }

    private static void tickMusic(Minecraft mc) {
        if (music == null) {
            if (phase == Phase.CLIMAX && awaitingEnd) sendFinished();   // nothing to wait for
            return;
        }
        boolean playing = mc.getSoundHandler().isPlaying(music);
        if (playing) seenPlaying = true;
        long elapsed = ticks - musicStart;
        boolean finished;
        if (seenPlaying) {
            finished = !playing;                                       // natural end reported by the sound engine
        } else if (elapsed > 40) {
            // engine never played it (volume 0 / device problem): wait the real length of the file
            finished = musicDurationTicks <= 0 || elapsed >= musicDurationTicks + 10;
        } else {
            finished = false;
        }
        if (!finished) return;

        music = null;
        if (phase == Phase.CHASE && loop) {
            startMusic(mc);            // chase still running -> next iteration, started exactly once
        } else if (awaitingEnd) {
            sendFinished();            // the track ended naturally after the climax
        }
    }

    private static void sendFinished() {
        awaitingEnd = false;
        phase = Phase.WAIT_RESTORE;
        endSentAt = ticks;
        ModNetwork.CHANNEL.sendToServer(new MusicFinishedPacket(sessionId));
    }

    private static void playEnding(Minecraft mc) {
        if (!mc.getResourceManager().hasResource(ENDING_FILE)) return;   // optional asset
        mc.getMusicTicker().stop();
        ISound s = new SimpleSound(ModSounds.ENDING_MUSIC.get(), SoundCategory.MUSIC, volume, 1.0F, false, 0,
                ISound.AttenuationType.NONE, 0.0D, 0.0D, 0.0D, true);
        ending = s;
        mc.getSoundHandler().play(s);
    }

    // ------------------------------------------------------------------ ambient (synced with the countdown)

    private static void tickHeartbeat(Minecraft mc) {
        if (!heartbeat || phase != Phase.CHASE) return;
        if (secondBeat > 0 && --secondBeat == 0) {
            mc.getSoundHandler().play(SimpleSound.master(SoundEvents.BLOCK_NOTE_BLOCK_BASEDRUM,
                    0.5F, 0.25F + 0.4F * intensity));
            secondBeat = -1;
        }
        if (--heartbeatCooldown > 0) return;
        heartbeatCooldown = Math.round(46.0F - 36.0F * intensity);      // 46 ticks calm -> 10 ticks at full tension
        mc.getSoundHandler().play(SimpleSound.master(SoundEvents.BLOCK_NOTE_BLOCK_BASEDRUM,
                0.6F, 0.35F + 0.55F * intensity));
        secondBeat = 5;
    }

    // ------------------------------------------------------------------ lifecycle

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.isGamePaused()) return;
        ticks++;
        ClientJumpscare.tick(mc);
        if (phase == Phase.IDLE) return;
        if (mc.player == null || mc.world == null) {
            reset(true);
            return;
        }
        tickMusic(mc);
        tickHeartbeat(mc);
        if (phase == Phase.WAIT_RESTORE && ticks - endSentAt > 400) reset(false);  // server never answered
    }

    /** @param stopAudio true = abort (cancel / logout): also cut music and the scream. false = normal end. */
    public static void reset(boolean stopAudio) {
        Minecraft mc = Minecraft.getInstance();
        if (stopAudio) {
            if (music != null && mc.getSoundHandler() != null) mc.getSoundHandler().stop(music);
            if (ending != null && mc.getSoundHandler() != null) mc.getSoundHandler().stop(ending);
            ending = null;
            ClientJumpscare.cancel();
        }
        music = null;
        phase = Phase.IDLE;
        awaitingEnd = false;
        intensity = 0.0F;
        shown = 0;
        heartbeatCooldown = 0;
        secondBeat = -1;
        reportedMissing = false;
    }

    @SubscribeEvent
    public static void onLoggedOut(ClientPlayerNetworkEvent.LoggedOutEvent e) {
        reset(true);
    }

    @SubscribeEvent
    public static void onWorldUnload(WorldEvent.Unload e) {
        if (e.getWorld().isRemote()) reset(true);
    }
}
