package com.strangedecisions.client;

import com.strangedecisions.JumpscareType;
import com.strangedecisions.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.SimpleSound;

/**
 * Full-screen jumpscare state. Each image is shown for a number of ticks, with or without the shared scream.
 * The scream is its own sound instance - it never touches the music.
 */
public final class ClientJumpscare {
    private static JumpscareType type;
    private static long start;
    private static long end;
    private static boolean freeze;
    private static boolean savedHideGui;
    private static ISound scream;

    private ClientJumpscare() {}

    public static void show(JumpscareType t, int durationTicks, boolean withSound, boolean freezeInput) {
        Minecraft mc = Minecraft.getInstance();
        cancel();
        type = t;
        start = ClientChase.ticks;
        end = start + Math.max(5, durationTicks);
        freeze = freezeInput;
        if (mc.gameSettings.hideGUI) {            // F1 would hide the overlay -> show the GUI for the duration
            savedHideGui = true;
            mc.gameSettings.hideGUI = false;
        }
        if (withSound) {
            scream = SimpleSound.master(ModSounds.JUMPSCARE_SCREAM.get(), 1.0F, 1.0F);
            mc.getSoundHandler().play(scream);    // same tick the image becomes visible
        }
    }

    public static void tick(Minecraft mc) {
        if (type != null && ClientChase.ticks >= end) finish();
    }

    /** Image finished: remove it and give control back. The scream (if still playing) is left alone. */
    private static void finish() {
        restoreState();
        type = null;
        scream = null;
    }

    /** Abort everything (cancel / logout). */
    public static void cancel() {
        Minecraft mc = Minecraft.getInstance();
        if (scream != null && mc.getSoundHandler() != null) mc.getSoundHandler().stop(scream);
        scream = null;
        restoreState();
        type = null;
    }

    private static void restoreState() {
        Minecraft mc = Minecraft.getInstance();
        if (savedHideGui) {
            mc.gameSettings.hideGUI = true;
            savedHideGui = false;
        }
        freeze = false;
    }

    public static boolean isActive() { return type != null; }
    public static boolean freezeInput() { return type != null && freeze; }
    public static JumpscareType type() { return type; }
    /** Elapsed ticks including the partial tick. */
    public static float elapsed(float pt) { return (ClientChase.ticks - start) + pt; }
    public static float total() { return end - start; }
}
