package com.strangedecisions.client;

import com.strangedecisions.StrangeDecisions;
import com.strangedecisions.entity.SteveStalkerEntity;
import net.minecraft.client.renderer.entity.BipedRenderer;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.model.PlayerModel;
import net.minecraft.util.ResourceLocation;

/** Renders Steve with the supplied bloody 64x64 player skin. */
public class SteveStalkerRenderer extends BipedRenderer<SteveStalkerEntity, PlayerModel<SteveStalkerEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(StrangeDecisions.MODID, "textures/entity/steve_stalker.png");

    public SteveStalkerRenderer(EntityRendererManager manager) {
        super(manager, new PlayerModel<SteveStalkerEntity>(0.0F, false), 0.5F);
    }

    @Override
    public ResourceLocation getEntityTexture(SteveStalkerEntity entity) {
        return TEXTURE;
    }
}
