package com.strangedecisions;

import net.minecraft.util.ResourceLocation;

/** Every jumpscare image the mod knows. Whether it screams is decided per case (config / command). */
public enum JumpscareType {
    //          texture               default sound   default ticks
    PEEK        ("jumpscare_peek",     false,          50),   // Steve peeking from behind a tree - silent
    PORTRAIT    ("jumpscare_portrait", true,           40),   // bloody portrait - with scream
    SECOND      ("jumpscare_second",   true,          100),   // chase climax - with scream
    PRISON      ("jumpscare_prison",   false,         120);   // prison rules - silent, after the chase

    public final String texture;
    public final boolean defaultSound;
    public final int defaultTicks;

    JumpscareType(String texture, boolean defaultSound, int defaultTicks) {
        this.texture = texture;
        this.defaultSound = defaultSound;
        this.defaultTicks = defaultTicks;
    }

    public ResourceLocation textureLocation() {
        return new ResourceLocation(StrangeDecisions.MODID, "textures/gui/" + texture + ".png");
    }

    public static JumpscareType byOrdinal(int i) {
        JumpscareType[] v = values();
        return (i >= 0 && i < v.length) ? v[i] : null;
    }

    public static JumpscareType byName(String s) {
        for (JumpscareType t : values()) {
            if (t.name().equalsIgnoreCase(s)) return t;
        }
        return null;
    }
}
