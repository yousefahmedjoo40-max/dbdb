package com.strangedecisions;

/**
 * Defines the chase progression. The same model drives (a) the displayed countdown while Steve is still
 * out of the loaded area, (b) Steve's target speed once he physically exists, (c) the display update interval.
 *
 *   d(t) = D0 * (1 - (0.15*p + 0.85*p^e)),   p = t/T,   e = 1 + accelerationRate
 *
 * The small linear term keeps the number moving at the start; the power term makes it accelerate.
 */
public final class ChaseModel {
    private static final double LINEAR = 0.15;

    public final double d0;
    public final double duration;
    public final double rate;
    private final double exponent;

    public ChaseModel(double d0, double durationSeconds, double rate) {
        this.d0 = d0;
        this.duration = Math.max(1.0, durationSeconds);
        this.rate = Math.max(0.0, rate);
        this.exponent = 1.0 + this.rate;
    }

    public double progress(double t) {
        return Math.max(0.0, Math.min(1.0, t / duration));
    }

    /** Virtual distance in blocks at time t (seconds). */
    public double distance(double t) {
        double p = progress(t);
        return d0 * (1.0 - (LINEAR * p + (1.0 - LINEAR) * Math.pow(p, exponent)));
    }

    /** Closing speed in blocks/second at time t. */
    public double speed(double t) {
        double p = progress(t);
        return d0 / duration * (LINEAR + (1.0 - LINEAR) * exponent * Math.pow(p, exponent - 1.0));
    }

    /** Ticks between two countdown updates: slow at the start, shrinks to minTicks near the end. */
    public int intervalTicks(double t, int baseTicks, int minTicks) {
        double p = progress(t);
        int v = (int) Math.round(baseTicks * Math.pow(1.0 - p, rate));
        return Math.max(minTicks, Math.min(baseTicks, v));
    }
}
