package com.strangedecisions;

import com.strangedecisions.entity.SteveStalkerEntity;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, StrangeDecisions.MODID);

    public static final RegistryObject<EntityType<SteveStalkerEntity>> STEVE_STALKER = ENTITIES.register("steve_stalker",
            () -> EntityType.Builder.<SteveStalkerEntity>create(SteveStalkerEntity::new, EntityClassification.MISC)
                    .size(0.6F, 1.8F)
                    .immuneToFire()
                    .disableSerialization() // never saved to disk -> no orphan Steves after a crash
                    .build(StrangeDecisions.MODID + ":steve_stalker"));

    private ModEntities() {}
}
