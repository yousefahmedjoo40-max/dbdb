package com.strangedecisions.network;

import com.strangedecisions.StrangeDecisions;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraftforge.fml.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(StrangeDecisions.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, ChasePacket.class, ChasePacket::encode, ChasePacket::decode, ChasePacket::handle);
        CHANNEL.registerMessage(id++, MusicFinishedPacket.class, MusicFinishedPacket::encode,
                MusicFinishedPacket::decode, MusicFinishedPacket::handle);
    }

    public static void sendTo(ServerPlayerEntity player, Object msg) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
    }

    private ModNetwork() {}
}
