package com.strangedecisions.network;

import com.strangedecisions.event.HorrorEventManager;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: the music track reached its natural end. */
public class MusicFinishedPacket {
    public final int session;

    public MusicFinishedPacket(int session) {
        this.session = session;
    }

    public static void encode(MusicFinishedPacket p, PacketBuffer b) {
        b.writeInt(p.session);
    }

    public static MusicFinishedPacket decode(PacketBuffer b) {
        return new MusicFinishedPacket(b.readInt());
    }

    public static void handle(MusicFinishedPacket p, Supplier<NetworkEvent.Context> ctx) {
        final ServerPlayerEntity sender = ctx.get().getSender();
        ctx.get().enqueueWork(() -> {
            if (sender != null) HorrorEventManager.onMusicFinished(sender, p.session);
        });
        ctx.get().setPacketHandled(true);
    }
}
