package com.strangedecisions.network;

import com.strangedecisions.client.ClientChase;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client. One flat packet; the 'type' decides which fields matter. */
public class ChasePacket {
    public static final int START = 0, UPDATE = 1, JUMPSCARE = 2, ENDING = 3, RESTORE = 4, CANCEL = 5;

    public int type;
    public int session;
    public int distance;
    public float intensity;
    public int jumpscare = -1;     // JumpscareType ordinal, -1 = no image
    public int ticks;
    public boolean sound;
    public boolean freeze;
    public boolean climax;
    public boolean loop;
    public boolean heartbeat;
    public float volume = 1.0F;

    public ChasePacket() {}

    public static ChasePacket simple(int type, int session) {
        ChasePacket p = new ChasePacket();
        p.type = type;
        p.session = session;
        return p;
    }

    public static ChasePacket start(int session, int distance, boolean loop, boolean heartbeat, float volume) {
        ChasePacket p = simple(START, session);
        p.distance = distance;
        p.loop = loop;
        p.heartbeat = heartbeat;
        p.volume = volume;
        return p;
    }

    public static ChasePacket update(int session, int distance, float intensity) {
        ChasePacket p = simple(UPDATE, session);
        p.distance = distance;
        p.intensity = intensity;
        return p;
    }

    public static ChasePacket jumpscare(int session, int typeOrdinal, int ticks, boolean sound, boolean freeze, boolean climax) {
        ChasePacket p = simple(JUMPSCARE, session);
        p.jumpscare = typeOrdinal;
        p.ticks = ticks;
        p.sound = sound;
        p.freeze = freeze;
        p.climax = climax;
        return p;
    }

    public static void encode(ChasePacket p, PacketBuffer b) {
        b.writeByte(p.type);
        b.writeInt(p.session);
        b.writeInt(p.distance);
        b.writeFloat(p.intensity);
        b.writeInt(p.jumpscare);
        b.writeInt(p.ticks);
        b.writeBoolean(p.sound);
        b.writeBoolean(p.freeze);
        b.writeBoolean(p.climax);
        b.writeBoolean(p.loop);
        b.writeBoolean(p.heartbeat);
        b.writeFloat(p.volume);
    }

    public static ChasePacket decode(PacketBuffer b) {
        ChasePacket p = new ChasePacket();
        p.type = b.readByte();
        p.session = b.readInt();
        p.distance = b.readInt();
        p.intensity = b.readFloat();
        p.jumpscare = b.readInt();
        p.ticks = b.readInt();
        p.sound = b.readBoolean();
        p.freeze = b.readBoolean();
        p.climax = b.readBoolean();
        p.loop = b.readBoolean();
        p.heartbeat = b.readBoolean();
        p.volume = b.readFloat();
        return p;
    }

    public static void handle(ChasePacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientChase.handle(p)));
        ctx.get().setPacketHandled(true);
    }
}
