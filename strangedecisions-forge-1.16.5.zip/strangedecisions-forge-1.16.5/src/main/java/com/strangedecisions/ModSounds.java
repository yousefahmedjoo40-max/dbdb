package com.strangedecisions;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, StrangeDecisions.MODID);

    /** The ONE scream shared by every jumpscare (assets/.../sounds/jumpscare_scream.ogg, unmodified). */
    public static final RegistryObject<SoundEvent> JUMPSCARE_SCREAM = reg("jumpscare_scream");
    public static final RegistryObject<SoundEvent> CHASE_MUSIC = reg("chase_music");
    public static final RegistryObject<SoundEvent> ENDING_MUSIC = reg("ending_music");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> new SoundEvent(new ResourceLocation(StrangeDecisions.MODID, name)));
    }

    private ModSounds() {}
}
