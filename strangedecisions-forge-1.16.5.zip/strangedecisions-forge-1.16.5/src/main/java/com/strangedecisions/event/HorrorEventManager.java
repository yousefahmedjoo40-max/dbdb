package com.strangedecisions.event;

import com.strangedecisions.ChaseModel;
import com.strangedecisions.JumpscareType;
import com.strangedecisions.ModEntities;
import com.strangedecisions.StrangeDecisions;
import com.strangedecisions.config.HorrorConfig;
import com.strangedecisions.entity.SteveStalkerEntity;
import com.strangedecisions.network.ChasePacket;
import com.strangedecisions.network.ModNetwork;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Direction;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.server.FMLServerStoppingEvent;
import net.minecraftforge.fml.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Server-side horror event manager. Owns the chase sessions and is the only place that decides
 * when jumpscares fire. Everything visual / audible is sent to the client with ChasePacket.
 */
@Mod.EventBusSubscriber(modid = StrangeDecisions.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class HorrorEventManager {
    private static final Map<UUID, ChaseSession> SESSIONS = new HashMap<>();
    private static final Map<String, Consumer<ServerPlayerEntity>> FOLLOW_UPS = new HashMap<>();
    private static final Random RANDOM = new Random();
    private static final String COOLDOWN_TAG = "sd_chase_last_climax";
    private static int nextSessionId = 1;

    static {
        registerFollowUp("none", p -> { });
        registerFollowUp("ending", HorrorEventManager::runEnding);
    }

    private HorrorEventManager() {}

    /** Other story events can plug in here and be selected with the 'followUpEvent' config value. */
    public static void registerFollowUp(String id, Consumer<ServerPlayerEntity> action) {
        FOLLOW_UPS.put(id, action);
    }

    public static boolean isActive(ServerPlayerEntity p) {
        return SESSIONS.containsKey(p.getUniqueID());
    }

    // ------------------------------------------------------------------ start / stop

    /** @return null on success, otherwise a human readable reason. */
    public static String startChase(ServerPlayerEntity p, boolean force) {
        if (!HorrorConfig.ENABLED.get()) return "the chase event is disabled in the config";
        if (SESSIONS.containsKey(p.getUniqueID())) return "a chase is already running for this player";
        ServerWorld w = p.getServerWorld();
        long now = w.getGameTime();
        CompoundNBT data = p.getPersistentData();
        if (!force && data.contains(COOLDOWN_TAG)
                && now - data.getLong(COOLDOWN_TAG) < HorrorConfig.COOLDOWN_SECONDS.get() * 20L) {
            return "cooldown is still active";
        }
        ChaseModel model = new ChaseModel(HorrorConfig.INITIAL_DISTANCE.get(),
                HorrorConfig.EVENT_DURATION_SECONDS.get(), HorrorConfig.ACCELERATION_RATE.get());
        ChaseSession s = new ChaseSession(nextSessionId++, p.getUniqueID(), w.getDimensionKey(), now, model);
        SESSIONS.put(p.getUniqueID(), s);
        ModNetwork.sendTo(p, ChasePacket.start(s.id, (int) Math.ceil(model.d0),
                HorrorConfig.LOOP_CHASE_MUSIC.get(), HorrorConfig.HEARTBEAT.get(),
                HorrorConfig.MUSIC_VOLUME.get().floatValue()));
        return null;
    }

    public static boolean stopChase(ServerPlayerEntity p) {
        ChaseSession s = SESSIONS.get(p.getUniqueID());
        if (s == null) return false;
        cancel(p.getServer(), s, p);
        return true;
    }

    /** Shows one jumpscare image immediately (used by the command). */
    public static void sendJumpscare(ServerPlayerEntity p, JumpscareType t, Boolean soundOverride) {
        boolean sound = soundOverride != null ? soundOverride : HorrorConfig.JS_SOUND[t.ordinal()].get();
        ModNetwork.sendTo(p, ChasePacket.jumpscare(0, t.ordinal(), ticksFor(t), sound, false, false));
    }

    private static int ticksFor(JumpscareType t) {
        return t == JumpscareType.SECOND ? HorrorConfig.SECOND_JUMPSCARE_TICKS.get() : t.defaultTicks;
    }

    public static void onMusicFinished(ServerPlayerEntity p, int sessionId) {
        ChaseSession s = SESSIONS.get(p.getUniqueID());
        if (s != null && s.id == sessionId && s.phase != ChaseSession.Phase.CHASE) {
            s.musicFinished = true;
        }
    }

    // ------------------------------------------------------------------ tick

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        if (!SESSIONS.isEmpty()) {
            for (ChaseSession s : new ArrayList<>(SESSIONS.values())) tickSession(server, s);
        }

        double chance = HorrorConfig.NATURAL_CHANCE_PER_MINUTE.get();
        if (chance > 0.0 && server.getTickCounter() % 1200 == 0) {
            for (ServerPlayerEntity p : new ArrayList<>(server.getPlayerList().getPlayers())) {
                if (p.world.getDimensionKey() == World.OVERWORLD && p.isAlive() && !p.isSpectator()
                        && RANDOM.nextDouble() < chance) {
                    startChase(p, false);
                }
            }
        }
    }

    private static void tickSession(MinecraftServer server, ChaseSession s) {
        ServerPlayerEntity p = server.getPlayerList().getPlayerByUUID(s.playerId);
        if (p == null) { cancel(server, s, null); return; }                         // disconnect
        if (!p.isAlive() || p.isSpectator()) { cancel(server, s, p); return; }      // death
        if (p.world.getDimensionKey() != s.dimension) { cancel(server, s, p); return; } // dimension change
        ServerWorld w = p.getServerWorld();
        long now = w.getGameTime();

        switch (s.phase) {
            case CHASE:
                tickChase(w, p, s, now);
                break;
            case CLIMAX:
                if (now >= s.climaxEnd) {
                    removeSteve(server, s);
                    releaseSlow(p, s);
                    s.phase = ChaseSession.Phase.AFTERMATH;   // image gone - the MUSIC keeps playing on the client
                }
                break;
            case AFTERMATH:
                if (s.musicFinished || now >= s.failsafeAt) finish(server, s, p);
                break;
            default:
                break;
        }
    }

    private static void tickChase(ServerWorld w, ServerPlayerEntity p, ChaseSession s, long now) {
        double t = (now - s.startTick) / 20.0;
        double modelD = s.model.distance(t);
        SteveStalkerEntity steve = findSteve(w, s);

        if (steve == null && modelD <= HorrorConfig.ENGAGE_DISTANCE.get()) {
            steve = spawnSteve(w, p, s, Math.max(10.0, modelD));
        }

        double real = steve != null ? steve.getDistance(p) : -1.0;
        double shown = steve != null ? real : modelD;

        // countdown message (accelerating update interval)
        if (now >= s.nextUpdate) {
            double frac = Math.max(0.0, Math.min(1.0, 1.0 - shown / s.model.d0));
            float intensity = (float) Math.pow(frac, 1.5);
            ModNetwork.sendTo(p, ChasePacket.update(s.id, (int) Math.ceil(shown), intensity));
            s.nextUpdate = now + s.model.intervalTicks(t, HorrorConfig.UPDATE_INTERVAL_TICKS.get(),
                    HorrorConfig.MIN_INTERVAL_TICKS.get());
        }

        // mid-chase scares at countdown thresholds (each may be silent or screaming, see config)
        int peekAt = HorrorConfig.PEEK_AT_DISTANCE.get();
        if (!s.peekDone && peekAt > 0 && shown <= peekAt) {
            s.peekDone = true;
            if (HorrorConfig.JS_ENABLED[JumpscareType.PEEK.ordinal()].get()) sendJumpscare(p, JumpscareType.PEEK, null);
        }
        int portraitAt = HorrorConfig.PORTRAIT_AT_DISTANCE.get();
        if (!s.portraitDone && portraitAt > 0 && shown <= portraitAt) {
            s.portraitDone = true;
            if (HorrorConfig.JS_ENABLED[JumpscareType.PORTRAIT.ordinal()].get()) sendJumpscare(p, JumpscareType.PORTRAIT, null);
        }

        if (steve != null) {
            if (now % 10 == 0) {
                double v = s.model.speed(t) + 0.5 * Math.max(0.0, real - modelD);   // catch up if the player runs
                if (t >= s.model.duration) v = HorrorConfig.MAX_ENTITY_SPEED.get();
                steve.setDesiredSpeed(Math.max(1.0, Math.min(HorrorConfig.MAX_ENTITY_SPEED.get(), v)));
            }
            checkStuck(w, p, s, steve, real, now);

            if (real <= HorrorConfig.CLIMAX_DISTANCE.get()) {
                beginClimax(w, p, s, steve, now);
                return;
            }
        }

        // hard deadline: the event may not last forever even if the player keeps running
        if (t >= s.model.duration + 8.0) {
            if (steve == null) steve = spawnSteve(w, p, s, 6.0);
            placeAdjacent(w, p, steve);
            beginClimax(w, p, s, steve, now);
        }
    }

    // ------------------------------------------------------------------ stuck recovery

    private static void checkStuck(ServerWorld w, ServerPlayerEntity p, ChaseSession s,
                                   SteveStalkerEntity steve, double real, long now) {
        if (now - s.lastStuckCheck < HorrorConfig.STUCK_CHECK_TICKS.get()) return;
        Vector3d pos = steve.getPositionVec();
        boolean stuck = false;
        if (s.lastStevePos != null && real > 4.0) {
            double dx = pos.x - s.lastStevePos.x;
            double dz = pos.z - s.lastStevePos.z;
            stuck = Math.sqrt(dx * dx + dz * dz) < 0.75;
        }
        s.lastStuckCheck = now;
        s.lastStevePos = pos;
        if (!stuck) { s.stuckCount = 0; return; }

        s.stuckCount++;
        if (s.stuckCount == 1) {
            // step 1: re-path and try to jump over the obstacle
            steve.getNavigator().clearPath();
            steve.getNavigator().tryMoveToEntityLiving(p, 1.0D);
            steve.nudgeJump();
        } else {
            // step 2+: teleport closer, preferably out of the player's sight
            double dist = Math.max(8.0, real * 0.6);
            Vector3d spot = findSpot(w, p, steve, dist, true);
            if (spot == null) spot = findSpot(w, p, steve, dist, false);
            if (spot != null) {
                steve.getNavigator().clearPath();
                steve.setPositionAndUpdate(spot.x, spot.y, spot.z);
                s.lastStevePos = spot;
            }
            s.stuckCount = 0;
        }
    }

    // ------------------------------------------------------------------ climax / finish

    private static void beginClimax(ServerWorld w, ServerPlayerEntity p, ChaseSession s,
                                    SteveStalkerEntity steve, long now) {
        if (s.jumpscareFired) return;                      // never twice for one session
        s.jumpscareFired = true;
        s.phase = ChaseSession.Phase.CLIMAX;

        boolean show = HorrorConfig.JS_ENABLED[JumpscareType.SECOND.ordinal()].get();
        boolean sound = show && HorrorConfig.JS_SOUND[JumpscareType.SECOND.ordinal()].get();
        boolean freeze = show && HorrorConfig.FREEZE_PLAYER.get();
        int ticks = show ? HorrorConfig.SECOND_JUMPSCARE_TICKS.get() : 0;

        if (steve != null) {
            faceTowards(steve, p);
            steve.freezeInPlace();
        }
        s.climaxEnd = now + ticks;
        s.failsafeAt = now + HorrorConfig.MUSIC_FAILSAFE_SECONDS.get() * 20L;
        if (freeze) {
            p.addPotionEffect(new EffectInstance(Effects.SLOWNESS, ticks + 10, 6, false, false, false));
            s.slowApplied = true;
        }
        p.getPersistentData().putLong(COOLDOWN_TAG, now);
        ModNetwork.sendTo(p, ChasePacket.jumpscare(s.id, show ? JumpscareType.SECOND.ordinal() : -1,
                ticks, sound, freeze, true));
    }

    private static void finish(MinecraftServer server, ChaseSession s, ServerPlayerEntity p) {
        releaseSlow(p, s);
        removeSteve(server, s);
        SESSIONS.remove(s.playerId);
        Consumer<ServerPlayerEntity> follow = FOLLOW_UPS.get(HorrorConfig.FOLLOW_UP.get());
        if (follow != null) follow.accept(p);
        ModNetwork.sendTo(p, ChasePacket.simple(ChasePacket.RESTORE, s.id));
    }

    /** Built-in follow-up: silent prison jumpscare + optional ending music. */
    private static void runEnding(ServerPlayerEntity p) {
        if (HorrorConfig.JS_ENABLED[JumpscareType.PRISON.ordinal()].get()) {
            sendJumpscare(p, JumpscareType.PRISON, null);
        }
        ModNetwork.sendTo(p, ChasePacket.simple(ChasePacket.ENDING, 0));
    }

    private static void cancel(MinecraftServer server, ChaseSession s, ServerPlayerEntity p) {
        removeSteve(server, s);
        SESSIONS.remove(s.playerId);
        if (p != null) {
            releaseSlow(p, s);
            ModNetwork.sendTo(p, ChasePacket.simple(ChasePacket.CANCEL, s.id));
        }
    }

    private static void releaseSlow(ServerPlayerEntity p, ChaseSession s) {
        if (!s.slowApplied) return;
        s.slowApplied = false;
        EffectInstance cur = p.getActivePotionEffect(Effects.SLOWNESS);
        if (cur != null && cur.getAmplifier() == 6 && !cur.doesShowParticles()) {
            p.removePotionEffect(Effects.SLOWNESS);
        }
    }

    // ------------------------------------------------------------------ Steve helpers

    private static SteveStalkerEntity findSteve(ServerWorld w, ChaseSession s) {
        if (s.steveId == null) return null;
        Entity e = w.getEntityByUuid(s.steveId);
        return (e instanceof SteveStalkerEntity && e.isAlive()) ? (SteveStalkerEntity) e : null;
    }

    private static void removeSteve(MinecraftServer server, ChaseSession s) {
        if (s.steveId == null) return;
        ServerWorld w = server.getWorld(s.dimension);
        if (w != null) {
            Entity e = w.getEntityByUuid(s.steveId);
            if (e != null) e.remove();
        }
        s.steveId = null;
    }

    private static SteveStalkerEntity spawnSteve(ServerWorld w, ServerPlayerEntity p, ChaseSession s, double dist) {
        SteveStalkerEntity steve = ModEntities.STEVE_STALKER.get().create(w);
        if (steve == null) return null;
        Vector3d spot = null;
        for (double d = dist; d >= 8.0 && spot == null; d *= 0.8) {
            spot = findSpot(w, p, steve, d, false);   // falls back to nearer spots if far chunks are not loaded
        }
        if (spot == null) return null;
        steve.setLocationAndAngles(spot.x, spot.y, spot.z, RANDOM.nextFloat() * 360.0F, 0.0F);
        steve.setChaseTarget(p.getUniqueID());
        steve.setDesiredSpeed(Math.max(1.0, s.model.speed((w.getGameTime() - s.startTick) / 20.0)));
        w.addEntity(steve);
        s.steveId = steve.getUniqueID();
        s.lastStevePos = spot;
        s.lastStuckCheck = w.getGameTime();
        return steve;
    }

    private static void placeAdjacent(ServerWorld w, ServerPlayerEntity p, SteveStalkerEntity steve) {
        if (steve == null) return;
        Vector3d look = p.getLookVec();
        double lx = look.x, lz = look.z;
        double len = Math.sqrt(lx * lx + lz * lz);
        if (len < 1.0E-4) { lx = 0; lz = 1; len = 1; }
        lx /= len;
        lz /= len;
        double[] dists = {2.0, -2.0, 3.0, -3.0};
        for (double d : dists) {
            double x = p.getPosX() + lx * d;
            double z = p.getPosZ() + lz * d;
            double y = p.getPosY();
            AxisAlignedBB box = steve.getType().getBoundingBoxWithSizeApplied(x, y, z);
            if (w.hasNoCollisions(box)) {
                steve.getNavigator().clearPath();
                steve.setPositionAndUpdate(x, y, z);
                return;
            }
        }
        steve.setPositionAndUpdate(p.getPosX(), p.getPosY(), p.getPosZ()); // last resort: on top of the player
    }

    private static void faceTowards(SteveStalkerEntity steve, ServerPlayerEntity p) {
        double dx = p.getPosX() - steve.getPosX();
        double dz = p.getPosZ() - steve.getPosZ();
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
        steve.rotationYaw = yaw;
        steve.rotationYawHead = yaw;
        steve.renderYawOffset = yaw;
    }

    /**
     * Finds a loaded, collision-free standing spot roughly 'dist' blocks from the player.
     * If 'hidden' is true the spot must be out of the player's line of sight.
     */
    private static Vector3d findSpot(ServerWorld w, ServerPlayerEntity p, SteveStalkerEntity steve,
                                     double dist, boolean hidden) {
        for (int attempt = 0; attempt < 24; attempt++) {
            double ang = RANDOM.nextDouble() * Math.PI * 2.0;
            double x = Math.floor(p.getPosX() + Math.cos(ang) * dist) + 0.5;
            double z = Math.floor(p.getPosZ() + Math.sin(ang) * dist) + 0.5;
            int py = (int) Math.floor(p.getPosY());
            for (int i = 0; i <= 24; i++) {
                int dy = (i % 2 == 0) ? i / 2 : -(i + 1) / 2;       // 0, -1, 1, -2, 2 ... closest to the player's height first
                BlockPos pos = new BlockPos(x, py + dy, z);
                if (!w.isBlockLoaded(pos) || !w.isBlockLoaded(pos.down())) break;
                if (!w.getBlockState(pos.down()).isSolidSide(w, pos.down(), Direction.UP)) continue;
                AxisAlignedBB box = steve.getType().getBoundingBoxWithSizeApplied(x, pos.getY(), z);
                if (!w.hasNoCollisions(box) || w.containsAnyLiquid(box)) continue;
                Vector3d spot = new Vector3d(x, pos.getY(), z);
                if (hidden) {
                    RayTraceContext ctx = new RayTraceContext(p.getEyePosition(1.0F), spot.add(0, 1.6, 0),
                            RayTraceContext.BlockMode.COLLIDER, RayTraceContext.FluidMode.NONE, p);
                    if (w.rayTraceBlocks(ctx).getType() == RayTraceResult.Type.MISS) continue;  // visible -> reject
                }
                return spot;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ cleanup events

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayerEntity) stopChase((ServerPlayerEntity) e.getEntity());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getPlayer() instanceof ServerPlayerEntity) stopChase((ServerPlayerEntity) e.getPlayer());
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getPlayer() instanceof ServerPlayerEntity) stopChase((ServerPlayerEntity) e.getPlayer());
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        CompoundNBT old = e.getOriginal().getPersistentData();
        if (old.contains(COOLDOWN_TAG)) e.getPlayer().getPersistentData().putLong(COOLDOWN_TAG, old.getLong(COOLDOWN_TAG));
    }

    @SubscribeEvent
    public static void onServerStopping(FMLServerStoppingEvent e) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        for (ChaseSession s : new ArrayList<>(SESSIONS.values())) {
            ServerPlayerEntity p = server == null ? null : server.getPlayerList().getPlayerByUUID(s.playerId);
            cancel(server, s, p);
        }
        SESSIONS.clear();
    }
}
