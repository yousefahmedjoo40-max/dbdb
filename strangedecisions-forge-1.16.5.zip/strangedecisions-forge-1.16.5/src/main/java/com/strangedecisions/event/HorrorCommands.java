package com.strangedecisions.event;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.strangedecisions.JumpscareType;
import com.strangedecisions.StrangeDecisions;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.command.arguments.EntityArgument;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * /strangedecisions chase start [player]      (ignores the cooldown)
 * /strangedecisions chase stop [player]
 * /strangedecisions jumpscare <peek|portrait|second|prison> [sound true|false] [player]
 */
@Mod.EventBusSubscriber(modid = StrangeDecisions.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class HorrorCommands {
    private HorrorCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSource> d = e.getDispatcher();
        d.register(Commands.literal("strangedecisions").requires(s -> s.hasPermissionLevel(2))
                .then(Commands.literal("chase")
                        .then(Commands.literal("start")
                                .executes(c -> start(c, c.getSource().asPlayer()))
                                .then(Commands.argument("target", EntityArgument.player())
                                        .executes(c -> start(c, EntityArgument.getPlayer(c, "target")))))
                        .then(Commands.literal("stop")
                                .executes(c -> stop(c, c.getSource().asPlayer()))
                                .then(Commands.argument("target", EntityArgument.player())
                                        .executes(c -> stop(c, EntityArgument.getPlayer(c, "target"))))))
                .then(Commands.literal("jumpscare")
                        .then(Commands.argument("type", StringArgumentType.word())
                                .executes(c -> scare(c, null, c.getSource().asPlayer()))
                                .then(Commands.argument("sound", BoolArgumentType.bool())
                                        .executes(c -> scare(c, BoolArgumentType.getBool(c, "sound"), c.getSource().asPlayer()))
                                        .then(Commands.argument("target", EntityArgument.player())
                                                .executes(c -> scare(c, BoolArgumentType.getBool(c, "sound"),
                                                        EntityArgument.getPlayer(c, "target"))))))));
    }

    private static int start(CommandContext<CommandSource> c, ServerPlayerEntity p) {
        String err = HorrorEventManager.startChase(p, true);
        c.getSource().sendFeedback(new StringTextComponent(err == null ? "Chase started for " + p.getName().getString()
                : "Could not start: " + err), true);
        return err == null ? 1 : 0;
    }

    private static int stop(CommandContext<CommandSource> c, ServerPlayerEntity p) {
        boolean ok = HorrorEventManager.stopChase(p);
        c.getSource().sendFeedback(new StringTextComponent(ok ? "Chase stopped." : "No chase running."), true);
        return ok ? 1 : 0;
    }

    private static int scare(CommandContext<CommandSource> c, Boolean sound, ServerPlayerEntity p) {
        JumpscareType t = JumpscareType.byName(StringArgumentType.getString(c, "type"));
        if (t == null) {
            c.getSource().sendFeedback(new StringTextComponent("Unknown type. Use: peek, portrait, second, prison"), false);
            return 0;
        }
        HorrorEventManager.sendJumpscare(p, t, sound);
        return 1;
    }
}
