package com.strangedecisions.event;

import com.strangedecisions.ChaseModel;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

import java.util.UUID;

/** All state of one chase for one player. Stored in HorrorEventManager.SESSIONS. */
final class ChaseSession {
    enum Phase { CHASE, CLIMAX, AFTERMATH }

    final int id;
    final UUID playerId;
    final RegistryKey<World> dimension;
    final long startTick;
    final ChaseModel model;

    Phase phase = Phase.CHASE;
    UUID steveId;
    long nextUpdate;
    Vector3d lastStevePos;
    long lastStuckCheck;
    int stuckCount;

    boolean jumpscareFired;      // the climax jumpscare may only fire once per session
    boolean peekDone;
    boolean portraitDone;
    boolean musicFinished;       // set when the client reports the track ended naturally
    boolean slowApplied;
    long climaxEnd;
    long failsafeAt;

    ChaseSession(int id, UUID playerId, RegistryKey<World> dimension, long startTick, ChaseModel model) {
        this.id = id;
        this.playerId = playerId;
        this.dimension = dimension;
        this.startTick = startTick;
        this.model = model;
        this.nextUpdate = startTick;
        this.lastStuckCheck = startTick;
    }
}
