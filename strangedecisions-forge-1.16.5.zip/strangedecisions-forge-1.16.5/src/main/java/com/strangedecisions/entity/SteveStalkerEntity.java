package com.strangedecisions.entity;

import net.minecraft.entity.CreatureEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.ai.attributes.AttributeModifierMap;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.OpenDoorGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.pathfinding.GroundPathNavigator;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.UUID;

/** The chasing Steve. Uses vanilla ground path navigation, never attacks - the climax is a jumpscare. */
public class SteveStalkerEntity extends CreatureEntity {
    private UUID targetId;
    private double desiredBps = 0.0;     // wanted speed, blocks / second
    private double speedAttr = 0.1;      // movement attribute actually applied
    private Vector3d lastPos;

    public SteveStalkerEntity(EntityType<? extends SteveStalkerEntity> type, World world) {
        super(type, world);
        this.setInvulnerable(true);
        this.enablePersistence();
        this.experienceValue = 0;
        if (this.getNavigator() instanceof GroundPathNavigator) {
            ((GroundPathNavigator) this.getNavigator()).setBreakDoors(true);
        }
    }

    public static AttributeModifierMap.MutableAttribute createAttributes() {
        return MobEntity.func_233666_p_()
                .createMutableAttribute(Attributes.MAX_HEALTH, 20.0D)
                .createMutableAttribute(Attributes.MOVEMENT_SPEED, 0.2D)
                .createMutableAttribute(Attributes.FOLLOW_RANGE, 128.0D)
                .createMutableAttribute(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new SwimGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, false));
        this.goalSelector.addGoal(2, new StalkGoal(this));
    }

    public void setChaseTarget(UUID playerId) {
        this.targetId = playerId;
    }

    public PlayerEntity getChaseTarget() {
        return targetId == null ? null : this.world.getPlayerByUuid(targetId);
    }

    /** Sets the wanted speed in blocks/second; a small closed-loop controller tunes the attribute to match it. */
    public void setDesiredSpeed(double bps) {
        if (desiredBps <= 0.0) {
            speedAttr = clamp(bps / 25.0, 0.02, 1.2);
        }
        desiredBps = bps;
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(speedAttr);
    }

    /** Called by the event manager for stuck recovery. */
    public void nudgeJump() {
        this.getJumpController().setJumping();
    }

    /** Stops all movement (used at the climax). */
    public void freezeInPlace() {
        this.getNavigator().clearPath();
        this.setNoAI(true);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.world.isRemote) return;
        if (getChaseTarget() == null) {   // target gone (logout, dimension change...) -> vanish
            this.remove();
            return;
        }
        if (this.ticksExisted % 10 == 0) {
            Vector3d pos = this.getPositionVec();
            if (lastPos != null && desiredBps > 0.0) {
                double dx = pos.x - lastPos.x;
                double dz = pos.z - lastPos.z;
                double bps = Math.sqrt(dx * dx + dz * dz) / 0.5;
                if (bps > 0.4 && !this.getNavigator().noPath()) {
                    speedAttr = clamp(speedAttr * clamp(desiredBps / bps, 0.85, 1.2), 0.02, 1.2);
                }
                this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(speedAttr);
            }
            lastPos = pos;
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        return source == DamageSource.OUT_OF_WORLD && super.attackEntityFrom(source, amount);
    }

    @Override
    public boolean canDespawn(double distanceToClosestPlayer) {
        return false;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Re-paths to the player every few ticks with vanilla navigation. */
    private static class StalkGoal extends Goal {
        private final SteveStalkerEntity steve;
        private int repath;

        StalkGoal(SteveStalkerEntity steve) {
            this.steve = steve;
            this.setMutexFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean shouldExecute() {
            return steve.getChaseTarget() != null;
        }

        @Override
        public boolean shouldContinueExecuting() {
            return steve.getChaseTarget() != null;
        }

        @Override
        public void startExecuting() {
            repath = 0;
        }

        @Override
        public void tick() {
            PlayerEntity target = steve.getChaseTarget();
            if (target == null) return;
            steve.getLookController().setLookPositionWithEntity(target, 30.0F, 30.0F);
            if (--repath <= 0) {
                repath = 6;
                steve.getNavigator().tryMoveToEntityLiving(target, 1.0D);
            }
        }
    }
}
