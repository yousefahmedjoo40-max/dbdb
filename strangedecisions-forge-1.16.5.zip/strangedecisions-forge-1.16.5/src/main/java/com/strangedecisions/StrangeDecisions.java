package com.strangedecisions;

import com.strangedecisions.config.HorrorConfig;
import com.strangedecisions.entity.SteveStalkerEntity;
import com.strangedecisions.network.ModNetwork;
import net.minecraft.entity.ai.attributes.GlobalEntityTypeAttributes;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;

@Mod(StrangeDecisions.MODID)
public class StrangeDecisions {
    public static final String MODID = "strangedecisions";

    public StrangeDecisions() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModSounds.SOUNDS.register(bus);
        bus.addListener(this::commonSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, HorrorConfig.SPEC);
        ModNetwork.register();
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> GlobalEntityTypeAttributes.put(
                ModEntities.STEVE_STALKER.get(), SteveStalkerEntity.createAttributes().create()));
    }
}
