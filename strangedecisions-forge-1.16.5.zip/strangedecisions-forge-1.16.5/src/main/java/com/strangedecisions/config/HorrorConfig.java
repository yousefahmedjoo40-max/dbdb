package com.strangedecisions.config;

import com.strangedecisions.JumpscareType;
import net.minecraftforge.common.ForgeConfigSpec;

public final class HorrorConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue ENABLED;
    // countdown / chase
    public static final ForgeConfigSpec.DoubleValue INITIAL_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue ACCELERATION_RATE;
    public static final ForgeConfigSpec.IntValue UPDATE_INTERVAL_TICKS;
    public static final ForgeConfigSpec.IntValue MIN_INTERVAL_TICKS;
    public static final ForgeConfigSpec.DoubleValue EVENT_DURATION_SECONDS;
    public static final ForgeConfigSpec.DoubleValue ENGAGE_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue CLIMAX_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue MAX_ENTITY_SPEED;
    public static final ForgeConfigSpec.IntValue STUCK_CHECK_TICKS;
    // audio / effects
    public static final ForgeConfigSpec.BooleanValue LOOP_CHASE_MUSIC;
    public static final ForgeConfigSpec.DoubleValue MUSIC_VOLUME;
    public static final ForgeConfigSpec.BooleanValue HEARTBEAT;
    public static final ForgeConfigSpec.BooleanValue CAMERA_SHAKE;
    public static final ForgeConfigSpec.IntValue MUSIC_FAILSAFE_SECONDS;
    // jumpscares (indexed by JumpscareType ordinal)
    public static final ForgeConfigSpec.BooleanValue[] JS_ENABLED = new ForgeConfigSpec.BooleanValue[JumpscareType.values().length];
    public static final ForgeConfigSpec.BooleanValue[] JS_SOUND = new ForgeConfigSpec.BooleanValue[JumpscareType.values().length];
    public static final ForgeConfigSpec.IntValue SECOND_JUMPSCARE_TICKS;
    public static final ForgeConfigSpec.BooleanValue FREEZE_PLAYER;
    public static final ForgeConfigSpec.IntValue PEEK_AT_DISTANCE;
    public static final ForgeConfigSpec.IntValue PORTRAIT_AT_DISTANCE;
    // story
    public static final ForgeConfigSpec.ConfigValue<String> FOLLOW_UP;
    public static final ForgeConfigSpec.IntValue COOLDOWN_SECONDS;
    public static final ForgeConfigSpec.DoubleValue NATURAL_CHANCE_PER_MINUTE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("general");
        ENABLED = b.comment("Master switch for the Steve chase event.").define("enabled", true);
        COOLDOWN_SECONDS = b.comment("Minimum seconds between two natural chase events for one player.")
                .defineInRange("cooldownSeconds", 600, 0, 86400);
        NATURAL_CHANCE_PER_MINUTE = b.comment("Chance per minute (0..1) that the chase starts by itself in the Overworld. 0 = only via command.")
                .defineInRange("naturalChancePerMinute", 0.0, 0.0, 1.0);
        FOLLOW_UP = b.comment("What happens after the music finishes: 'ending' (silent prison jumpscare + ending music) or 'none'.")
                .define("followUpEvent", "ending");
        b.pop();

        b.push("countdown");
        INITIAL_DISTANCE = b.comment("Distance shown at the start (HE IS AWAY FROM YOU: N BLOCKS).")
                .defineInRange("initialDistance", 200.0, 20.0, 2000.0);
        EVENT_DURATION_SECONDS = b.comment("Seconds from the start until Steve is forced to reach the player.")
                .defineInRange("eventDurationSeconds", 90.0, 15.0, 1200.0);
        ACCELERATION_RATE = b.comment("0 = constant speed. Higher = the countdown accelerates harder near the end.")
                .defineInRange("accelerationRate", 1.6, 0.0, 6.0);
        UPDATE_INTERVAL_TICKS = b.comment("Ticks between countdown updates at the very start.")
                .defineInRange("updateIntervalTicks", 20, 1, 200);
        MIN_INTERVAL_TICKS = b.comment("Smallest number of ticks between countdown updates (reached near the end).")
                .defineInRange("minCountdownIntervalTicks", 1, 1, 100);
        b.pop();

        b.push("steve");
        ENGAGE_DISTANCE = b.comment("Steve physically spawns and walks (entity navigation) once the model distance drops below this.")
                .defineInRange("engageDistance", 96.0, 16.0, 160.0);
        CLIMAX_DISTANCE = b.comment("Real distance at which the climax jumpscare fires.")
                .defineInRange("climaxDistance", 2.5, 1.0, 8.0);
        MAX_ENTITY_SPEED = b.comment("Maximum Steve speed in blocks/second.")
                .defineInRange("maxEntitySpeed", 7.0, 2.0, 20.0);
        STUCK_CHECK_TICKS = b.comment("Stuck detection window in ticks. When stuck Steve re-paths, then teleports closer.")
                .defineInRange("stuckCheckTicks", 40, 10, 200);
        b.pop();

        b.push("audio");
        LOOP_CHASE_MUSIC = b.comment("Re-start the chase track when it ends naturally while the chase is still running.")
                .define("loopChaseMusicDuringChase", true);
        MUSIC_VOLUME = b.defineInRange("musicVolume", 1.0, 0.0, 1.0);
        HEARTBEAT = b.comment("Heartbeat thumps whose speed follows the countdown.").define("heartbeat", true);
        CAMERA_SHAKE = b.define("cameraShake", true);
        MUSIC_FAILSAFE_SECONDS = b.comment("Server-side safety net if a client never reports the end of the music (disconnect etc).")
                .defineInRange("musicFailsafeSeconds", 300, 30, 3600);
        b.pop();

        b.push("jumpscares");
        for (JumpscareType t : JumpscareType.values()) {
            b.push(t.name().toLowerCase());
            JS_ENABLED[t.ordinal()] = b.define("enabled", true);
            JS_SOUND[t.ordinal()] = b.comment("true = the shared scream plays with this image, false = silent.")
                    .define("sound", t.defaultSound);
            b.pop();
        }
        SECOND_JUMPSCARE_TICKS = b.comment("How long the second (climax) image stays on screen.")
                .defineInRange("secondJumpscareTicks", 100, 20, 400);
        FREEZE_PLAYER = b.comment("Freeze the player while the second jumpscare image is shown.")
                .define("freezePlayerDuringSecond", true);
        PEEK_AT_DISTANCE = b.comment("During the chase, show the silent PEEK image when the countdown reaches this value (0 = never).")
                .defineInRange("peekAtDistance", 150, 0, 2000);
        PORTRAIT_AT_DISTANCE = b.comment("During the chase, show the PORTRAIT image when the countdown reaches this value (0 = never).")
                .defineInRange("portraitAtDistance", 70, 0, 2000);
        b.pop();

        SPEC = b.build();
    }

    private HorrorConfig() {}
}
